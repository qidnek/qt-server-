#include <QCoreApplication>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QTextStream>
#include <iostream>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

void displayDetails(QSqlDatabase &db) {
    QSqlQuery query(db);
    if (query.exec("SELECT Name, Brand, Model, Price, Quantity FROM Details")) {
        QTextStream(stdout) << "\nParts List:\n";
        QTextStream(stdout) << "----------------------------------------\n";
        while (query.next()) {
            QString name = query.value(0).toString();
            QString brand = query.value(1).toString();
            QString model = query.value(2).toString();
            double price = query.value(3).toDouble();
            int quantity = query.value(4).toInt();

            QTextStream(stdout) << "Name: " << name
                                << "\nBrand: " << brand
                                << "\nModel: " << model
                                << "\nPrice: " << price
                                << "\nQuantity: " << quantity
                                << "\n----------------------------------------\n";
        }
    } else {
        QTextStream(stderr) << "Error executing query: " << query.lastError().text() << "\n";
    }
}

bool authenticate(QSqlDatabase &db, const QString &login, const QString &password) {
    QSqlQuery query(db);
    query.prepare("SELECT Login, Pass FROM Users WHERE Login = :login");
    query.bindValue(":login", login);

    if (query.exec() && query.next()) {
        QString storedPassword = query.value("Pass").toString();

        if (storedPassword == password) {
            QTextStream(stdout) << "Authentication successful! Welcome, " << login << ".\n";
            return true;
        } else {
            QTextStream(stdout) << "Incorrect password.\n";
            return false;
        }
    } else {
        QTextStream(stdout) << "Login not found.\n";
        return false;
    }
}

int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);

    // Настройки подключения к PostgreSQL
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");
    db.setHostName("localhost");
    db.setDatabaseName("radioshop");
    db.setUserName("postgres");
    db.setPassword("14nm05nm");

    if (!db.open()) {
        QTextStream(stderr) << "Error connecting to the database: " << db.lastError().text() << "\n";
        return -1;
    }

    QTextStream input(stdin);
    QTextStream output(stdout);

    output << "Welcome! Please log in.\n";
    output << "Login: ";
    output.flush();
    QString login = input.readLine();

    output << "Password: ";
    output.flush();
    QString password = input.readLine();

    if (authenticate(db, login, password)) {
        // Здесь вызывается функция displayDetails (ее необходимо реализовать)
        QTextStream(stdout) << "Accessing user details...\n";
    }

    db.close();
    return 0;
}
